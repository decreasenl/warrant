export interface ISystemNotification {
  title: string,
  body: string
}