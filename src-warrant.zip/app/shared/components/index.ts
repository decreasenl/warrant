export * from './pages/page-not-found/page-not-found.component';
